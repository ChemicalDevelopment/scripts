/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-6.3.0/configure --enable-languages=c++,fortran";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "core2" } };
